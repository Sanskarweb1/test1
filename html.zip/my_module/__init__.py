
def greet(name):
    return f"Hello, {name}! This is your offline module."
